import React from "react";

const SearchPanel = () => {
    return <input placeholder="search" className="form-control search-input" />;
};

export default  SearchPanel;